<template>
  <b-col lg="3">Here sidebar</b-col>
</template>

<script lang="ts">
import Vue from 'vue'
export default Vue.extend({})
</script>
