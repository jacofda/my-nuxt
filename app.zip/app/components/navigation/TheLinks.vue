<template>
  <b-navbar-nav>
    <b-nav-item to="/about">About</b-nav-item>
    <b-nav-item to="/contact">Contact</b-nav-item>
    <b-nav-item to="/dogs">Dogs</b-nav-item>
  </b-navbar-nav>
</template>
