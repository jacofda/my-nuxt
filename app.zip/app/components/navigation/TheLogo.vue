<template>
  <NuxtLink to="/" class="navbar-brand">Logo</NuxtLink>
</template>
