<template>
  <b-nav-item-dropdown text="User" right>
    <b-dropdown-item href="#">Profile</b-dropdown-item>
    <b-dropdown-item href="#">Sign Out</b-dropdown-item>
  </b-nav-item-dropdown>
</template>
